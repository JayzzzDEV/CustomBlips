fx_version 'cerulean'
game 'gta5'

author 'Ex_method'
description 'Custom Blips'
version '1.1.0'

files({
	"blips/blips.lua",
})

client_script 'blips/blips.lua'
server_script 'server/server.lua'
shared_script 'config.lua'

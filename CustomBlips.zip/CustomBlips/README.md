╔═══╗────────╔╗╔╗──────╔╗
║╔══╝───────╔╝╚╣║──────║║
║╚══╦╗╔╦╗╔╦═╩╗╔╣╚═╦══╦═╝║
║╔══╩╬╬╣╚╝║║═╣║║╔╗║╔╗║╔╗║
║╚══╦╬╬╣║║║║═╣╚╣║║║╚╝║╚╝║
╚═══╩╝╚╩╩╩╩══╩═╩╝╚╩══╩══╝

          Made In 2023

My Github:https://github.com/Exmethod
My Discord:https://discord.gg/k6PCNs9mFK


-----------------Info--------------------

To edit the blips and add more blips go to the Blips Folder and open the Blips.lua
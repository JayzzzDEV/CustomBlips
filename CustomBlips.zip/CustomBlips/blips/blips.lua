-- ╔═══╗────────╔╗╔╗──────╔╗
-- ║╔══╝───────╔╝╚╣║──────║║
-- ║╚══╦╗╔╦╗╔╦═╩╗╔╣╚═╦══╦═╝║
-- ║╔══╩╬╬╣╚╝║║═╣║║╔╗║╔╗║╔╗║
-- ║╚══╦╬╬╣║║║║═╣╚╣║║║╚╝║╚╝║
-- ╚═══╩╝╚╩╩╩╩══╩═╩╝╚╩══╩══╝
-- Add as much stuff as you need
-- Cfx Blips website: https://docs.fivem.net/docs/game-references/blips/
-- Make Sure all of the Blips have spaces whe it say example= 1,
local blips = {

     {title="Restaurant MP", size=1.0, colour=51, id=674, category= example, x = 285.4491, y = -936.8715, z = 29.400} --285.4491, -936.8715, 29.4009, 120.0487
}

-- Do not touch any thing under this
Citizen.CreateThread(function()

    for _, info in pairs(blips) do
      info.blip = AddBlipForCoord(info.x, info.y, info.z)
      SetBlipSprite(info.blip, info.id)
      SetBlipDisplay(info.blip, 2)
      SetBlipScale(info.blip, info.size)
      SetBlipCategory(info.blip, info.category)
      SetBlipColour(info.blip, info.colour)
      SetBlipAsShortRange(info.blip, true)
      BeginTextCommandSetBlipName("STRING")
      AddTextComponentString(info.title)
      EndTextCommandSetBlipName(info.blip)
    end
end)

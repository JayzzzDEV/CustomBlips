Config = {}
-- config.show is the Ex_method logo that shows up in the cmd if you want to turn it off change true to false.
Config.show = true 